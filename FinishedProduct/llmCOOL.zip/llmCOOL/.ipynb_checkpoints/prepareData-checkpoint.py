import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import GPT2Tokenizer, DataCollatorWithPadding
from transformer import Transformer
from torch.utils.data import DataLoader
from datasets import load_dataset, load_from_disk



# dataset
# https://huggingface.co/datasets/Skylion007/openwebtext/tree/main
dataset = load_dataset("Skylion007/openwebtext", trust_remote_code=True)

tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token

# tokenize data
def tokenize_function(examples):
    return tokenizer(examples['text'], truncation=True, max_length=512)
# # tokenized data
if __name__ == "__main__":    
    tokenized_dataset = dataset.map(tokenize_function, batched=True, num_proc = 14)
    tokenized_dataset.save_to_disk('/home/ubuntu/test/llmCOOL')